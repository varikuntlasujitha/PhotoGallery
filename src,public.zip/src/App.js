import './App.css';
import Register from './Register';
import Welcome from './Welcome';
import { Link, Switch, Route, UseHistory, UseLocation, useHistory, useLocation } from "react-router-dom";
import Login from './Login';
import Header from './Header';
import Addimages from './Addimages';
import Search from './Search';



function App() {
  return (
    <div className="App">
      <Header></Header>
    </div>
  );
}

export default App;