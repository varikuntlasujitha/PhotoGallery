import React, { Component } from 'react';
import './RegistrationCss.css';
import background from "./images/img12.jpg";

class Register extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      name:'',
      email:'',
      phone:'',
      password:''
    }
  }
  
  onChangeName = (e) =>{
    this.setState({name:e.target.value})
  }

  onChangeEmail = (e) =>{
    this.setState({email:e.target.value})
  }

  onChangePhone = (e) =>{
    this.setState({phone:e.target.value})
  }

  onChangePassword = (e) =>{
    this.setState({password:e.target.value})
  }

  onSubmit = (e) =>{
    let { history } = this.props
    let ob = {
      name: this.state.name,
      email: this.state.email,
      phone: this.state.phone,
      password: this.state.password,
    }
    let olddata = localStorage.getItem('formdata');
    if(olddata==null){
      olddata = []
      olddata.push(ob)
      localStorage.setItem('formdata', JSON.stringify(olddata));
      history.push({ pathname: "/Welcome" });
    }else{
      let oldArr = JSON.parse(olddata)
      oldArr.push(ob)
      localStorage.setItem("formdata", JSON.stringify(oldArr))
      console.log(oldArr,'hhg')
      alert("Registration successfull")
      history.push({ pathname: "/login" });
    }
    
  }

  render() {
    const myStyle={
      backgroundImage: `url(${background})`,
      height:'100vh',
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat',
      padding:40 ,
  };
    return (
      
      <form onSubmit={this.onSubmit}>
        <div id="main-registration-container" style={myStyle}>
      <div id="register">
        <div className="form-group">
        <h3>Registration Page</h3>
          <label>Name</label>
          <input type="text" placeholder="Albert Instean" className="form-control" value={this.state.name} onChange={this.onChangeName} required />
        </div>
        <div className="form-group">
          <label>Phone</label>
          <input type="tel" placeholder="0123456789" className="form-control" value={this.state.phone} onChange={this.onChangePhone} required />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input type="email" placeholder="abc@xyz.com" className="form-control" value={this.state.email} onChange={this.onChangeEmail} required />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" placeholder="#########" className="form-control" value={this.state.password} onChange={this.onChangePassword} required />
        </div>
        <br></br><button type="submit" className="btn btn-primary btn-block">Register</button>
        </div>
        </div>
      </form>
    )
  }
}

export default Register;