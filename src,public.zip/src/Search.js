import React,{useEffect,useState} from 'react';
import { Link } from 'react-router-dom';

import axios from 'axios';
import Gallery from './Gallery';
import Logout from './Logout';

const apiKey = "636e1481b4f3c446d26b8eb6ebfe7127";
const Search = () => {
  const [data,setData] = useState([]);
  const [search,setSearch] = useState("");
  useEffect(()=>{
    },[])
  const changeHandler = e =>{
    setSearch(e.target.value);
  }
  const submitHandler = e =>{
    e.preventDefault();
    axios
    .get(
      `https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=${apiKey}&tags=${search}&per_page=24&format=json&nojsoncallback=1`
    )
    .then(response => {
      setData(response.data.photos.photo)
    })
    .catch(error => {
      console.log(
        "Encountered an error with fetching and parsing data",
        error
      );
  })
  }
  return (
    <div>
      <Logout></Logout>
      <center>
        <h1>Hunting</h1><br></br>
        <form onSubmit={submitHandler}>
          <input style={{width:500,borderRadius:"5px"}} size="40" type="text" onChange={changeHandler} value={search}/><br /><br />
          <input style={{width:500,borderRadius:"5px" ,fontWeight:"bold",fontSize:20} }type="submit" name="Search" />
        </form>
        <br />
        {data.length>=1?<Gallery data={data}/>:<h4>No Image Loaded</h4>}
      </center>
      <Link className="btn btn-outline-dark" style={{fontWeight:"bold",fontSize:20}} to="/Welcome">GO Home</Link>

    </div>
  )
}

export default Search;
