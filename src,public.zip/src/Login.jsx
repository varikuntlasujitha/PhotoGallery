import React, { Component } from 'react';
import './RegistrationCss.css';
//import Welcome from './Welcome';
import background from "./images/img12.jpg";

class Login extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      name:'',
      email:'',
      phone:'',
      password:'',
      error:''
    }
  }

  onChangeName = (e) =>{
    this.setState({name:e.target.value})
  }

  onChangeEmail = (e) =>{
    this.setState({email:e.target.value})
  }

  onSubmit = (e) =>{
    let { history } = this.props
    let ele;
    e.preventDefault()
    let olddata = localStorage.getItem('formdata')
    let oldArr = JSON.parse(olddata)
    oldArr.map(arr => 
      {
        if(this.state.email.length > 0 && this.state.password.length > 0){
          if (arr.email == this.state.email && (arr.password == this.state.password)) {
            let user = this.state.email;
            alert("User Logged in");
            history.push({ pathname: "./Welcome" });
            
          }else{
            this.setState({error:'Please check your email or password'})
          }
        }
      }
      )
  }
  
  onChangePassword = (e) =>{
    this.setState({password:e.target.value})
  }

  render() {
    const myStyle={
      backgroundImage: `url(${background})`,
      height:'100vh',
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat',
      padding:60,
  };
    
    return (
      <form onSubmit={this.onSubmit}>
          <div id="main-registration-container" style={myStyle}>
        <div id="register">
        <p className="error">
          {this.state.error}
        </p>
        <div className="form-group">
          <h3>Login Page</h3><br></br>
          <label >Email</label>
          <input type="email" className="form-control" placeholder="left" value={this.state.email} onChange={this.onChangeEmail} required />
        </div>
        <div className="form-group">
          <label >Password</label>
          <input type="password" className="form-control" placeholder="password"value={this.state.password} onChange={this.onChangePassword} required />
        </div><br></br>
        <button type="submit" className="btn btn-primary btn-block" onClick={this.props.onLogin}>Login</button>
        </div>
        </div>
      </form>
    )
  }
}

export default Login;