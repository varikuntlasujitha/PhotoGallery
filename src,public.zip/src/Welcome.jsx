import React, { Component } from 'react';
import './RegistrationCss.css';
import { Link, Switch, Route } from 'react-router-dom';
import background from "./images/img12.jpg";
class Welcome extends Component {
    constructor(props) {
        super(props);
        this.logOut = this.logOut.bind(this);
    }
    
    logOut( )  {

        alert("User Logged out Successfully")
        
       window.location.href = '/login';
    }
    render() { 
        const myStyle={
            backgroundImage: `url(${background})`,
            height:"100vh",
            backgroundSize: 'cover' ,
            backgroundRepeat: 'no-repeat',
            padding:60,
        };
        return ( 
            <div style={myStyle}>
              <div>
                  <nav >
              <Link  to="/Photo"  style={{float:"left",fontWeight:"bold"}} id="link1"className='btn btn-outline-dark'>Gallery</Link>
              </nav>
              <div id="logout" style={{float:"right",paddingTop:"-30px"}}>
                  <button type='submit' className="btn btn-outline-dark" style={{fontWeight:"bold"}} onClick={this.logOut.bind()}>Logout</button> 
                  </div>
                  <h1>Welcome To My Gallery</h1>
                  
              </div>
            </div>
         );
    }
}
 
export default Welcome;