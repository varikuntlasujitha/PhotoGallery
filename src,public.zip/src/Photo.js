
import { Link } from 'react-router-dom';
import background from "./images/img12.jpg";
import Logout from './Logout';
function Photo() {
    function Display()
    {

        alert("Hey!! my favourite  images");
    }
    const myStyle={
        backgroundImage: `url(${background})`,
        height:'100vh',
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        padding:60,
    };

    return ( 
        <div style={myStyle}>
            <Logout></Logout>
            <Link to={{pathname:"/Display"}}>


            <input type="button"className="btn btn-outline-dark"style={{opacity:0.7,width:500,marginTop:"6px",fontWeight:"bold", fontsize:60,alignContent:"center"}} onClick={Display} value="Images"/>
</Link>
<br/><br/><br/><br/>
<br/><br/>
<br/><br/>

<div><h1>If you want to see images plzz click above</h1></div>

</div>    
 );
}

export default Photo;