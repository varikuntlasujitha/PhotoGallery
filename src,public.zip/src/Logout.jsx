import React, { Component } from 'react';

import background from "./images/img12.jpg";
class Logout extends Component {
    constructor(props) {
        super(props);
        this.logOut = this.logOut.bind(this);
    }
    
    
    logOut( )  {

        alert("User Logged out Successfully")
        
       window.location.href = '/login';
    }
    render() { 
        

        return ( 
            
            <div id="logout" style={{float:"right",paddingTop:"-30px"}}>
                  <button type='submit' className="btn btn-outline-dark" style={{fontWeight:"bold",marginTop:"30px",marginRight:"30px"}} onClick={this.logOut.bind()}>Logout</button>  
                  </div>
            
            
         );
    }
}
 
export default Logout;