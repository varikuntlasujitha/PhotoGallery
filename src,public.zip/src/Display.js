import logo from './logo.svg';
import './App.css';
import background from "./images/img12.jpg";

import Addimages from './Addimages';

import Logout from './Logout';
import img1 from "./images/img1.jpg"
import img2 from "./images/img2.jpg"
import img4 from "./images/img4.jpg"
import img5 from "./images/img5.jpg"
import img3 from "./images/img3.jpg"
import img6 from "./images/img6.jpg"
import img8 from "./images/img8.jpg"
import img7 from "./images/img7.jpg"
import img9 from "./images/img9.jpg"
import img11 from "./images/img11.jpg"
import img10 from "./images/img10.jpg"
import img13 from "./images/img13.jpg"
import { Link } from 'react-router-dom';
function Display() {
    const myStyle={
        backgroundImage: `url(${background})`,
        height:'100vh',
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        padding:60,
    };
  return (
    <div className="App">
        <Logout style={{float: 'right'}}></Logout>
<h1>DISPLAY IMAGES</h1>

<h3 style={{float: 'left'}}>Today</h3> <br/>

      <img src={img1} alt="" style={{width: "10%" , height:"20vh" , float:'left'}}/>
      
      <img src={img2} alt="" style={{width: "10%" , height:"20vh" , float:'left' }}/>

      <img src={img4} alt="" style={{width: "10%" , height:"20vh" ,float:'left' }}/>
      
      <br/><br/><br/><br/><br/><br/><br/><br/><br/>
      <h3 style={{float: 'left'}}>Yesterday</h3> <br/>

      <img src={img5} alt="" style={{width: "10%" , height:"20vh" , float:'left'}}/>
      <img src={img3} alt="" style={{width: "10%" , height:"20vh" , float:'left'}}/>
      <img src={img6} alt="" style={{width: "10%" , height:"20vh" , float:'left'}}/>
      <br/><br/><br/><br/><br/><br/><br/><br/><br/>

<h3 style={{float: 'left'}}>20-APR-22</h3>
<br/>
      
      <img src={img7} alt="" style={{width: "10%" , height:"20vh",float:'left' }}/>
      <img src={img8} alt="" style={{width: "10%" , height:"20vh",float:'left' }}/>
      <img src={img13} alt="" style={{width: "10%" , height:"20vh",float:'left' }}/>

      <br/><br/><br/><br/><br/><br/><br/><br/><br/>

  <h3 style={{float: 'left'}}>19-APR-21</h3>  <br/>
  <br/>  
      <img src={img10} alt="" style={{width: "10%" , height:"20vh",float:'left'  }}/>
      <img src={img9} alt="" style={{width: "10%" , height:"20vh" ,float:'left'}}/>
      <br/>
      <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>

<Link className="btn btn-outline-dark" style={{fontWeight:"bold"}} to="/Addimages">ADDimages</Link>





    </div>
  );
}

export default Display;
