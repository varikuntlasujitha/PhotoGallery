import React,{Component} from 'react'
import Register from './Register';
import Welcome from './Welcome';
import { Link, Switch, Route, UseHistory, UseLocation, useHistory, useLocation } from "react-router-dom";
import Photo from './Photo';
import Login from './Login';
import Display from './Display';
import Addimages from './Addimages';
import Search from './Search';
import './App.css';

class Header extends Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        
        
        return (  
            <div className="App">
                
                
      <nav class="topnav"> 
          <Link to="/reg" id="link3" className="btn btn-outline-light">Register</Link>
          <Link to="/login" id="link2" className="btn btn-outline-light"> Login</Link>





          
        </nav>
        <Switch>
          <Route path="/login" exact component={Login}/>
          <Route path="/reg" exact component={Register}/>  

          <Route path="/Welcome" exact component={Welcome}/> 
<Route path="/Display" exact component={Display}/>
<Route path="/Photo" exact component={Photo}/>
<Route path="/Addimages" exact component={Addimages}/>
<Route path="/Search" exact component={Search}/>




        </Switch>
        
    </div>
        );
    }
}
 
export default Header;